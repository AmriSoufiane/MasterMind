# MasterMind
* A reproduction in c# of thepopular game MasterMind
* 3 files
* View.cs for the display
* MasterM.cs where are the class of the program
* ScoreSaver.cs where it create directory to save score
